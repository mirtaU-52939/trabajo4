import java.util.Scanner;
import java.util.concurrent.Semaphore;


public class TurnoHilo {
	private int cantidad;
	private int turno;
	private Semaphore mutex;
	
			
	
	public TurnoHilo(int cant){
		this.cantidad=cant;
		mutex=new Semaphore(1);
		this.turno=1;
	}
	 
	public int getTurno()
	 {
		 return turno;
	 } 
	public int getcantidad()
	 {
		 return cantidad;
	 } 
	
	private void setTurno(String cadena) throws InterruptedException
	{mutex.acquire();
	this.turno++;
	System.out.print(cadena);
	mutex.release();
	}

	private void reiniciarTurno(String cadena) throws InterruptedException
	{mutex.acquire();
	this.cantidad--;
	this.turno=1;
	System.out.print(cadena);
	mutex.release();
	}
	/*public synchronized void Escribir (int numTurno)throws InterruptedException
	{	
		
		switch(numTurno){	
			case 1: System.out.print("A");this.setTurno(2); break;
			case 2: System.out.print("BB");this.setTurno(3);break;
			case 3: System.out.print("CCC");this.setTurno(1);break;
	
				}
	}*/
	
	public void Escribir (TurnoHilo t, String c)throws InterruptedException
	{	
		if (t.getTurno()!=3){t.setTurno(c);}
		else{t.reiniciarTurno(c);}
		}
	}
	
	