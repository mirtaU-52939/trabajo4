
public class HiloC implements Runnable{

TurnoHilo turno;
String cadena;	
	public HiloC( TurnoHilo t){
		this.cadena="CCC";
		this.turno=t;
	}; 
	
public void run() {
		
		try {
			
			this.turno.Escribir(this.turno, this.cadena);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}}
		
	

}