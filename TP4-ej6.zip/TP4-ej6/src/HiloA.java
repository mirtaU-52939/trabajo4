
public class HiloA implements Runnable{
	
	TurnoHilo turno;
	String cadena;
	
	public HiloA(TurnoHilo t){
		this.cadena="A";
		this.turno=t;
		
	}; 
	
	public void run() {
		
		try {
			this.turno.Escribir(this.turno, this.cadena);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	}
		


