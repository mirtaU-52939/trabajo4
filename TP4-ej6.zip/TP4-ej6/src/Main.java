import java.io.IOException;
import java.util.Scanner;


public class Main {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException{
		int i;
		System.out.print("ingrese la cantidad de veces que desea repetir");
		i=System.in.read();
		
		TurnoHilo turno=new TurnoHilo(i);
		HiloA hiloA= new HiloA(turno);
		HiloB hiloB= new HiloB(turno);
		HiloC hiloC= new HiloC(turno);		
					
		
		Thread T1= new Thread( hiloA);
		Thread T2= new Thread( hiloB);
		Thread T3= new Thread( hiloC);
		
		
		T1.start();
		T2.start();
		T3.start();
		
		
	}
		}


