
public class Carrera {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Posta posta=new Posta();
		Corredor c1= new Corredor(posta,"corredor1");
		Corredor c2= new Corredor(posta,"corredor2");
		Corredor c3= new Corredor(posta,"corredor3");
		Corredor c4= new Corredor(posta,"corredor4");
					
		
		Thread T1= new Thread(c1);
		Thread T2= new Thread(c2);
		Thread T3= new Thread(c3);
		Thread T4= new Thread(c4);
		
		T1.start();
		T2.start();
		T3.start();
		T4.start();
		
		
}
}