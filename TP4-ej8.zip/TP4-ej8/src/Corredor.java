
public class Corredor implements Runnable {
	Posta testigo;
	String corredor;

	
	public Corredor(Posta p, String c){
		this.testigo=p;
		this.corredor=c;
		
	}; 
	
	
		public void run(){
			try {
				Thread.sleep(1000);
				this.testigo.correr(this.corredor);
				
								
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
				
	}

}
