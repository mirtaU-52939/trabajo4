import java.util.concurrent.Semaphore;


public class Posta {

private Semaphore mutex;


public Posta(){
	
	mutex=new Semaphore(1);
	
}
 

public void correr(String c) throws InterruptedException
{mutex.acquire();

Math.random();
System.out.println("el tiempo al final del corredor "+ c +" es "+ System.currentTimeMillis());


mutex.release();
}


}
